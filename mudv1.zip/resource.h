#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDM__RELOAD_CONFIGURATION1              40000
#define IDM__ABOUT1                             40001
#define IDM__QUIT1                              40002
